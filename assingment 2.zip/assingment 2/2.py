x=10
i=1
while i <=x:
    if i%2==0:
        print(i)
    i=i+1