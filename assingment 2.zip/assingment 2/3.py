for ch in "kakama.edson@guild.org":
    if ch == "@":
        print(ch)
        break
    print(ch,end="")