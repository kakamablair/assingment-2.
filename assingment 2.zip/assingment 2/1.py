for i in range(0,10):
    if i%2!= 0:
     print(i)