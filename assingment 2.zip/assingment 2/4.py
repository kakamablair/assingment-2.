for digit in "0165031806510":
    if digit == "0":
        digit = "X"
    print(digit)